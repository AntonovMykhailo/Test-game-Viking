﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    private float timeBtwAttack;
    public float startTimeBtwAttack;
    public GameObject soundDamage;
    public int health;
    public float speed;
    public int damage;
    private float stopTime;
    public float startStopTime;
    public float normalSpeed;
    private PlayerMove player;
    private Animator anim;
    public Transform pos1, pos2;
    public Transform startPos;
    Vector3 nextPos;

    private void Start()
     {
        anim = GetComponent<Animator>();
        player = FindObjectOfType<PlayerMove>();
        normalSpeed = speed;
        nextPos = startPos.position;
    }


    private void Update()
    {
        if(stopTime <= 0)
        {
            speed = normalSpeed;
        }
        else
        {
            speed = 0;
            stopTime -= Time.deltaTime;
        }
       
        if (health <= 0)
        {
            Destroy(gameObject);
        }
        // Следовать за игроком
        /*
        if(player.transform.position.x > transform.position.x)
        {
            transform.eulerAngles = new Vector3(0, 180, 0);
        }
        else
        {
            transform.eulerAngles = new Vector3(0, 0, 0);
        }*/
        //transform.position = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime); // Враг следует за игроком 

        transform.position = Vector3.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);

        if (transform.position == pos1.position)
        {
            nextPos = pos2.position;
             transform.localScale = new Vector2(-1, 1);
        }
        if (transform.position == pos2.position)
        {
            nextPos = pos1.position;
             transform.localScale = new Vector2(1, 1);
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawLine(pos1.position, pos2.position);
    }

    public void TakeDamage(int damage)
    {
        stopTime = startStopTime;
        health -= damage;
    }
    public void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (timeBtwAttack <= 0)
            {
                anim.SetTrigger("AttackEnemy");
            }
            else
            {
                timeBtwAttack -= Time.deltaTime;
            }
        }
    }
    public void OnEnemyAttack()
    {
        player.health -= damage;
        timeBtwAttack = startTimeBtwAttack;
        Instantiate(soundDamage, transform.position, Quaternion.identity);
    }
}