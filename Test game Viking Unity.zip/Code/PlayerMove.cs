﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMove : MonoBehaviour //Класс игрока
{
    public Rigidbody2D rb; //Сила притяжения игрока
    public Animator anim;//Анимация игрока
    public float health;//Здоровье игрока
    public int numOfHearts;//Количество сердечек
    public Image[] hearts;//Массив изображения сердечкам
    public Sprite fullHeart;//Спрайт заполненного сердечка
    public Sprite emptyHeart;//Спрайт пустого сердечка
    public float heal;//Время восстановления одного сердечка
    private ScoreManeger scoreCoins;//Счетчик монет
    public GameObject soundCoin;//Звук монет

    //------- Метод, выполняемый при запуске игры ---------
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();             // 
        anim = GetComponent<Animator>();              //Назначения переменным их компонентов
        scoreCoins = FindObjectOfType<ScoreManeger>();//
    }

    //------- Метод, выполняемый каждый кадр в игре ---------
    void Update()
    {
        Walk();           //
        Reflect();        //Вызов методов 
        Jump();           //
        CheckingGround(); //
        if (health > numOfHearts)//Если здоровье больше, чем количество сердечек
        {
            health = numOfHearts;//Здоровье не превышать количество сердечек 
        }
        health += Time.deltaTime * heal;//Восстановление здоровья 

        for (int i = 0; i<hearts.Length; i++)//Цикл заполнения сердечек
        {
            if (i < Mathf.RoundToInt(health))
            {
                hearts[i].sprite = fullHeart;
            }
            else
            {
                hearts[i].sprite = emptyHeart;
            }
            if (i < numOfHearts)
            {
                hearts[i].enabled = true;
            }
            else
            {
                hearts[i].enabled = false;
            }
        }
        if (health < 1)//Если игрок погиб
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);//Перезапуск уровня
        }
        if (Input.GetKey("escape"))  // если нажата клавиша Esc (Escape)
        {
            Application.Quit();    // закрыть приложение
        }
    }

    //------- Метод для перемещения персонажа по горизонтали ---------
    public Vector2 moveVector;
    public int speed = 3;//Скорость игрока
    void Walk()
    {
        moveVector.x = Input.GetAxisRaw("Horizontal");
        rb.velocity = new Vector2(moveVector.x * speed, rb.velocity.y);
        anim.SetFloat("moveX", Mathf.Abs(moveVector.x));
    }

    //------- Метод нахождения персонажа в зоне платформе ---------
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name.Equals("Platform"))//Если игрок на платформе 
        {
            this.transform.parent = collision.transform;//Он двигается в туже сторону что и она 
        } 
    }

    //------- Метод покидание персонажа зоны платформе ---------
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.name.Equals("Platform"))//Если игрок не на платформе 
        {
            this.transform.parent = null;//Он не двигается в туже сторону что и она
        }
    }

    //------- Метод для отражения персонажа по горизонтали ---------
    public bool faceRight = true;
    void Reflect()
    {
        if ((moveVector.x > 0 && !faceRight) || (moveVector.x < 0 && faceRight))
        {
            transform.localScale *= new Vector2(-1, 1);
            faceRight = !faceRight;
        }
    }

    //------- Метод для прыжка и спуска с платформы ---------
    public float jumpForce = 7f;//Сила прыжка 
    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.W) && onGround)//Если нажата кнопка W и он на земле
        {
            rb.velocity = new Vector2(rb.velocity.x, 0);//
            rb.AddForce(Vector2.up * jumpForce * 4 );   //Игрок подпрыгивает
           // Instantiate(soundSteps, transform.position, Quaternion.identity);
        }
        if (Input.GetKeyDown(KeyCode.S))//Если нажата кнопка S
        {
            Physics2D.IgnoreLayerCollision(9, 10, true);//
            Invoke("IgnoreLayerOff", 0.59f);            //Игрок спускается с платформы
            // Instantiate(soundSteps, transform.position, Quaternion.identity);
        }
    }

    //------- Метод для отключения игнорирования слоев ---------
    void IgnoreLayerOff()
    {
        Physics2D.IgnoreLayerCollision(9, 10, false);
    }

    //------- Метод для взаимодействия с объектами определенного тега ---------
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Coin"))//Если игрок столкнулся с монеткой
        {
            Instantiate(soundCoin, transform.position, Quaternion.identity);//Пересечение игрока и монетки
            Destroy(other.gameObject);//Монетка уничтожается 
            scoreCoins.Coins();//Счетчик увеличивается на одну единицу
        }
    }

    //------- Метод для обнаружения земли ---------
    public bool onGround;//Нахождение игрока на земле
    public Transform GroundCheck;
    public float checkRadius = 0.5f;//Радиус обнаружения
    public LayerMask Ground;

    void CheckingGround()
    {
        onGround = Physics2D.OverlapCircle(GroundCheck.position, checkRadius, Ground);
        anim.SetBool("onGround", onGround);//Анимация игрока в состоянии покоя 
    }
    //---------------------------------------------
}