﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManeger : MonoBehaviour
{
    public int coins;
    public Text scoreDisplay;
    public Sprite FullWin;
    public Sprite emptyWin;
    public Image Win;
    public GameObject soundWin;

    private void Update()
    {
        scoreDisplay.text = coins.ToString() + "/7";
        
    }
    public void Coins()
    {
        coins++;
        if (coins == 7)
        {
            Win.sprite = FullWin;
            Instantiate(soundWin, transform.position, Quaternion.identity);
        }
        else
        {
            Win.sprite = emptyWin;
        }
    }
}